// Dependency-free local server for the included production build.
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve, extname, sep } from "node:path";
const root = fileURLToPath(new URL("./dist/", import.meta.url));
const port = Number(process.env.PORT || 4173);
const inCodespaces = process.env.CODESPACES === "true";
const host = inCodespaces ? "0.0.0.0" : "127.0.0.1";
const codespaceName = process.env.CODESPACE_NAME;
const forwardingDomain =
  process.env.GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN || "app.github.dev";
const previewUrl =
  inCodespaces && codespaceName
    ? `https://${codespaceName}-${port}.${forwardingDomain}/demo`
    : `http://127.0.0.1:${port}/demo`;
const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ttf": "font/ttf",
  ".json": "application/json",
};
const server = createServer(async (req, res) => {
  try {
    const path = decodeURIComponent(
      new URL(req.url, "http://localhost").pathname,
    );
    let file = resolve(root, "." + path);
    if (file !== resolve(root) && !file.startsWith(resolve(root) + sep)) {
      res.writeHead(403);
      res.end();
      return;
    }
    try {
      if (!(await stat(file)).isFile()) file = resolve(root, "index.html");
    } catch {
      if (extname(path)) {
        res.writeHead(404);
        res.end();
        return;
      }
      file = resolve(root, "index.html");
    }
    const body = await readFile(file);
    res.writeHead(200, {
      "Content-Type": types[extname(file)] || "application/octet-stream",
      "Cache-Control": "no-cache",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(body);
  } catch {
    res.writeHead(500);
    res.end();
  }
});
server.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    console.error(
      `Port ${port} is already in use. Stop the earlier server with Ctrl+C, or run: PORT=${port + 1} npm start`,
    );
  } else {
    console.error(`Unable to start SEMI Freight: ${error.message}`);
  }
  process.exitCode = 1;
});
server.listen(port, host, () => {
  console.log(
    `SEMI Freight · ${inCodespaces ? "Codespaces preview" : "Local demo"}\n${previewUrl}\nCtrl+C to stop.`,
  );
  if (inCodespaces)
    console.log(
      "Keep port visibility set to Private. Ctrl+click the HTTPS link above to open the prototype.",
    );
});
